let formData = {
    name: "",
    email: "",
    password: "",
    confirmPassword: ""
};
let signInEL = document.getElementById("signInForm");
let addUserFormEl = document.getElementById("addUserForm");
let signUpFormEl = document.getElementById("signUpForm");
let signInbtnEL = document.getElementById("signUpbtn");
let signUpbtnEl = document.getElementById("signInbtn");

let nameEl = document.getElementById("name");
let nameErrMsgEl = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");

let passwordEl = document.getElementById("password");
let passwordErrMsgEl = document.getElementById("passwordErrMsg");

let confirmPasswordEl = document.getElementById("confirmPassword");
let confirmPasswordErrMsgEl = document.getElementById("confirmPasswordErrMsg");


let errorMsg = "Required*";
nameEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        nameErrMsgEl.textContent = errorMsg;
    } else {
        nameErrMsgEl.textContent = "";
    }
    formData.name = event.target.value;
});

emailEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        emailErrMsgEl.textContent = errorMsg;
    } else {
        emailErrMsgEl.textContent = "";
    }
    formData.email = event.target.value;
});

passwordEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        passwordErrMsgEl.textContent = errorMsg;
    } else {
        passwordErrMsgEl.textContent = "";
    }
    formData.password = event.target.value;
});

confirmPasswordEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        confirmPasswordErrMsgEl.textContent = errorMsg;
    } else {
        confirmPasswordErrMsgEl.textContent = "";
    }
    formData.confirmPassword = event.target.value;
});

function submitFormData(formData) {
    let options = {
        method: "POST",

        body: JSON.stringify(formData)
    };

    let url = "https://logathon-signup.herokuapp.com/web/signup";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);

        });
}
addUserFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    submitFormData(formData);

});


function signIn() {
    signUpFormEl.classList.add("form-hidden");
    signInEL.classList.remove("form-hidden");
}

function signUp() {
    signUpFormEl.classList.remove("form-hidden");
    signInEL.classList.add("form-hidden");
}